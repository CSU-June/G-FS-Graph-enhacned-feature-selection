import numpy as np
import pandas as pd

def cal_all_aver_result(args):
    if args.problem == "Regression":
        list = ['[0]_test_MSE.csv', '[1]_test_MSE.csv', '[2]_test_MSE.csv', '[3]_test_MSE.csv', '[4]_test_MSE.csv']
        df = pd.read_csv(args.path_result + "{}_".format(args.method) + list[0])
        df = pd.DataFrame(df)
        for i in range(1, len(list)):
            df1 = pd.read_csv(args.path_result +"{}_".format(args.method) + list[i])
            df1 = pd.DataFrame(df1)
            df[i] = df1
        a = np.array(df)
        df[5] = np.mean(a, axis=1)
        df[6] = np.std(a, axis=1)
        df.to_csv(args.path_result + "{}_{}_all_test_MSE.csv".format(args.method, args.data), encoding="utf_8_sig", index=False, header=True, mode='a+')

        list_MAE = ['[0]_test_MAE.csv', '[1]_test_MAE.csv', '[2]_test_MAE.csv', '[3]_test_MAE.csv', '[4]_test_MAE.csv']
        df = pd.read_csv(args.path_result + "{}_".format(args.method)+list_MAE[0])
        df = pd.DataFrame(df)
        for i in range(1, len(list_MAE)):
            df1 = pd.read_csv(args.path_result +"{}_".format(args.method) + list_MAE[i])
            df1 = pd.DataFrame(df1)
            df[i] = df1
        a = np.array(df)
        df[5] = np.mean(a, axis=1)
        df[6] = np.var(a, axis=1)
        df.to_csv(args.path_result + "{}_{}_all_test_MAE.csv".format(args.method,args.data), encoding="utf_8_sig", index=False, header=True,mode='a+')

    if args.problem == "Classification":
        list = ['[0]_test_ACC.csv', '[1]_test_ACC.csv', '[2]_test_ACC.csv', '[3]_test_ACC.csv', '[4]_test_ACC.csv']
        df = pd.read_csv(args.path_result + "{}_".format(args.method) + list[0])
        df = pd.DataFrame(df)
        for i in range(1, len(list)):
            df1 = pd.read_csv(args.path_result + "{}_".format(args.method) + list[i])
            df1 = pd.DataFrame(df1)
            df[i] = df1
        a = np.array(df)
        df[5] = np.mean(a, axis=1) * 100
        df[6] = np.std(a, axis=1) * 100
        df.to_csv(args.path_result + "{}_{}_all_test_ACC.csv".format(args.method, args.data), encoding="utf_8_sig", index=False, header=True, mode='a+')

    list_weight = ['[0]_weight.csv', '[1]_weight.csv', '[2]_weight.csv', '[3]_weight.csv', '[4]_weight.csv']
    df = pd.read_csv(args.path_result + "{}_".format(args.method) + list_weight[0])
    df = pd.DataFrame(df)
    for i in range(1, len(list_weight)):
        df1 = pd.read_csv(args.path_result + "{}_".format(args.method) + list_weight[i])
        df1 = pd.DataFrame(df1)
        df[i] = df1
    a = np.array(df)
    df[5] = np.mean(a, axis=1)
    df[6] = np.var(a, axis=1)
    df.to_csv(args.path_result + "{}_{}_all_weight.csv".format(args.method, args.data), encoding="utf_8_sig", index=False, header=True, mode='a+')

def Statistics_diff_algorithms(args):
    if args.problem == "Regression":
        list = ['grape_attention', 'lgb', 'xgb', 'rf', 'DT']#, 'attention'
        df_all = pd.DataFrame({'feature_nums': np.arange(1, 31, 1)})
        for i in list:
            df_diff_method = pd.read_csv(args.log_path + "/{}_lgb0.7_{}".format(args.data, args.select_sample) + "/{}/".format(i) + "result_data_{}/{}/{}/".format(args.hidden_dim, args.noise_type, args.noise_amount) + "{}_{}_all_test_MAE.csv".format(i, args.data), usecols=[5])
            # df1 = pd.DataFrame(df_diff_method[-2])
            df_all.insert(df_all.shape[1], i, df_diff_method)
        a = np.array(df_all)
        # df_all['mean'] = np.mean(a, axis=1)
        # df_all[len(list)+2] = np.var(a, axis=1, columns="var")
        df_all.to_csv(args.log_path +"/{}_lgb0.7_{}/".format(args.data, args.select_sample)+ "{}_[{}]_all_alg_test_MAE.csv".format(args.noise_type, args.noise_amount), encoding="utf_8_sig",
                  index=False, header=True, mode='a+')
    if args.problem == "Classification":
        list = ['grape_attention', 'lgb', 'xgb', 'rf', 'DT']#, 'attention'
        df_all = pd.DataFrame({'feature_nums': np.arange(1, 31, 1)})
        for i in list:
            df_diff_method = pd.read_csv(
                args.log_path + "/{}_lgb0.7_{}".format(args.data, args.select_sample) + "/{}/".format(i) + "result_data_{}/{}/{}/".format(args.hidden_dim,
                    args.noise_type, args.noise_amount) + "{}_{}_all_test_ACC.csv".format(i, args.data), usecols=[5])
            # df1 = pd.DataFrame(df_diff_method[-2])
            df_all.insert(df_all.shape[1], i, df_diff_method)
        a = np.array(df_all)
        # df_all['mean'] = np.mean(a, axis=1)
        # df_all[len(list)+2] = np.var(a, axis=1, columns="var")
        df_all.to_csv(args.log_path + "/{}_lgb0.7_{}/".format(args.data, args.select_sample) + "{}_[{}]_all_alg_test_ACC.csv".format(args.noise_type,
                                                                                                       args.noise_amount),
                      encoding="utf_8_sig",
                      index=False, header=True, mode='a+')

def cal_all_avg_all_class(args):
    if args.problem == "Classification":
        for j in range(0,5,1): # 5 class
            list = ['[0]_test_ACC_cls{}.csv'.format(j), '[1]_test_ACC_cls{}.csv'.format(j), '[2]_test_ACC_cls{}.csv'.format(j), '[3]_test_ACC_cls{}.csv'.format(j), '[4]_test_ACC_cls{}.csv'.format(j)]
            df = pd.read_csv(args.path_result + "{}_".format(args.method) + list[0])
            df = pd.DataFrame(df)
            for i in range(1, len(list)):
                df1 = pd.read_csv(args.path_result + "{}_".format(args.method) + list[i])
                df1 = pd.DataFrame(df1)
                df[i] = df1
            a = np.array(df)
            df[5] = np.mean(a, axis=1) * 100
            df[6] = np.std(a, axis=1) * 100
            df.to_csv(args.path_result + "{}_{}_all_test_ACC_cls{}.csv".format(args.method, args.data,j), encoding="utf_8_sig", index=False, header=True, mode='a+')
