"""VIME: Extending the Success of Self- and Semi-supervised Learning to Tabular Domain (VIME) Codebase.

Reference: Jinsung Yoon, Yao Zhang, James Jordon, Mihaela van der Schaar,
"VIME: Extending the Success of Self- and Semi-supervised Learning to Tabular Domain,"
Neural Information Processing Systems (NeurIPS), 2020.
Paper link: TBD
Last updated Date: October 11th 2020
Code author: Jinsung Yoon (jsyoon0823@gmail.com)
-----------------------------

data_loader.py
- Load and preprocess MNIST data (http://yann.lecun.com/exdb/mnist/)
"""

# Necessary packages
import matplotlib.pyplot as plt
import numpy as np
import scipy.io
import pandas as pd
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
# import tensorflow.contrib.keras as keras
# from keras.utils.np_utils import *
import util
from sklearn import preprocessing


def load_data(args, label_no, i, normalize=True):
    """MNIST data loading.

    Args:
      - label_data_rate: ratio of labeled data

    Returns:
      - x_label, y_label: labeled dataset
      - x_unlab: unlabeled dataset
      - x_test, y_test: test dataset
    """
    # 原始数据
    np.random.seed(40 + i)
    if args.problem == "Regression":
        df_np = np.loadtxt('./data/{}/data/data.txt'.format(args.data))
        y = pd.DataFrame(df_np[:, -1:])
        x = pd.DataFrame(df_np[:, :-1])
    if args.problem == "Classification":
        x = pd.read_csv("./data/{}/data/data.csv".format(args.data))
        y = pd.read_csv("./data/{}/data/label.csv".format(args.data))

    df_y1 = np.array(y)
    df_X = np.array(x)
    df_y = np.array(y)
    df_X = pd.DataFrame(df_X)
    # normalize
    if normalize:
        x = df_X.values
        min_max_scaler = preprocessing.MinMaxScaler()
        x_scaled = min_max_scaler.fit_transform(x)
        df_X = pd.DataFrame(x_scaled)
    Y = np.array(df_y)
    raw_data = np.array(df_X)
    df_X = np.array(df_X)
    # Y = np.squeeze(Y)

    # Please put the rebuild table under this directory
    pred_data = pd.read_csv(
        "./data/{}/data/{}_{}_{}_pred_test1_mytest.csv".format(args.data, args.noise_amount, args.data,
                                                               args.noise_type))

    data = np.array(pred_data)

    if args.problem == 'Classification':
        if args.data == 'mnist':
            data = data.reshape(2000, -1)
            # 400 800 1200 1600 2000
            df_X = df_X[:2000, :]
            df_y = df_y[:2000, :]
            data = data[:2000, :]
        else:
            data = data.reshape(df_y1.shape[0], -1)
            # data = data.reshape(5000, -1)
            # select_y = util.initLabeled_ini(df_y, i, args)
            # df_X = df_X[select_y, :]
            # df_y = df_y[select_y, :]
            # data = data[select_y]
            # idx = np.random.permutation(len(df_y))
            # df_X = df_X[idx, :]
            # df_y = df_y[idx, :]
            # data = data[idx, :]
            df_X = df_X[:5000, :]
            df_y = df_y[:5000, :]
            data = data[:5000, :]
    else:  # regression
        data = data.reshape(Y.shape[0], -1)

    Y = np.array(df_y)
    raw_data = np.array(df_X)

    data = pd.DataFrame(data)

    x_train, x_test, y_train, y_test = train_test_split(data, Y, test_size=0.3, random_state=0)  # 7:3
    print("x_train.shape:", x_train.shape)
    print(y_train.shape)
    print("x_test.shape:", x_test.shape)
    print(y_test.shape)
    x_train = np.array(x_train)
    y_train = np.array(y_train)

    x_test = np.array(x_test)
    y_test = np.array(y_test)

    x_unlab = x_train

    idx = np.random.permutation(len(y_train))
    x_train = x_train[idx, :]
    y_train = y_train[idx]

    select_y = util.initLabeled(y_train, i, args)
    x_train_weight = x_train[select_y]
    Y_select = y_train[select_y]

    # noise
    if args.noise_type == "mask":
        mask_matrix = np.random.binomial(n=1, p=1.0 - args.noise_amount, size=x_train_weight.shape)
        x_train_weight = x_train_weight * mask_matrix
    else:
        if args.noise_type == "s&p":
            x_train_weight = util.random_noise(x_train_weight, mode="s&p", amount=args.noise_amount)
        else:
            x_train_weight = util.random_noise(x_train_weight, mode=args.noise_type, var=0.3, mean=0)
    encoder = LabelBinarizer()
    if args.problem == "Classification":
        Y_select = encoder.fit_transform(Y_select)  # // regression 注释

    # regression 10%
    if args.problem == 'Regression':
        label_no = int(x.shape[0] / 10)
    # training classifier / regressor
    x_train_raw, x_test_raw, y_train_raw, y_test_raw = train_test_split(raw_data, Y, test_size=0.3, random_state=0)

    x_train_raw = np.array(x_train_raw)
    y_train_raw = np.array(y_train_raw)

    raw_data_train = x_train_raw[idx, :]
    raw_Y_train = y_train_raw[idx, :]
    raw_x_train_weight = x_train_raw[:label_no, :]
    raw_y_train_weight = raw_Y_train[:label_no]

    # ============ no used ================
    select_y_orig = util.initLabeled(raw_y_train_weight, i, args)
    orig_data_select = raw_x_train_weight[select_y_orig]
    orig_Y_select = raw_y_train_weight[select_y_orig]
    if args.problem == "Classification":
        orig_Y_select = encoder.fit_transform(orig_Y_select)
        raw_y_train_weight = encoder.fit_transform(raw_y_train_weight)

    raw_data_classify = raw_data_train[label_no:, :]
    raw_Y_classify = raw_Y_train[label_no:]
    print("raw_x_train_weight.shape:", raw_x_train_weight.shape)
    print("raw_data_classify.shape:", raw_data_classify.shape)
    # ============ no used ================

    return x_unlab, x_test_raw, y_test_raw, x_train_weight, Y_select, raw_data_train, raw_Y_train
