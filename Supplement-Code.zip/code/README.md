#python=3.7.1

#Step1： 
##pip install -r requirement.txt

#Step2:  
##wget https://pytorch-geometric.com/whl/torch-1.4.0+cu101/torch_cluster-1.5.4-cp37-cp37m-linux_x86_64.whl
##wget https://pytorch-geometric.com/whl/torch-1.4.0+cu101/torch_scatter-2.0.4-cp37-cp37m-linux_x86_64.whl
##wget https://pytorch-geometric.com/whl/torch-1.4.0+cu101/torch_sparse-0.6.1-cp37-cp37m-linux_x86_64.whl
##pip install *.whl
##pip install torch-geometric==2.0

#Step3: 
##python train_graph_module.py --epochs 20000 --train_edge 1.0 --data 'optdigits'
##The graph model will be saved in "./uci/test/"

#Step4: 
##python load_mdi.py --noise_amount 0.0 
##Rebuilding the tabular data without mask. 
##For example, the results of optdigits will be saved in "./data/optdigits/", then copy the new tabular data into "./data/optdigits/data"

#Step5: 
##python main.py --data 'optdigits' --problem 'Classification' --noise_amount 0.0 --classifier lgb --select_sample 50 --select_features 10
##The results of feature selection will be saved in  "./train/optdigits"

#*More detail parameters please see train_graph_module.py and main.py


