import numpy as np
from collections import OrderedDict
def mask_generator (p_m, x):
    """Generate mask vector.

    Args:
      - p_m: corruption probability
      - x: feature matrix

    Returns:
      - mask: binary mask matrix
    """
    mask = np.random.binomial(1, p_m, x.shape)
    return mask

def initLabeled(y,i,args):
    ## random selected the labeled instances' index
    y = np.squeeze(y)
    np.random.seed(40+i)
    labeledIndex = []
    labelDict = OrderedDict()
    for label in np.unique(y):
        # if label <5:
            labelDict[label] = []
    for i, label in enumerate(y):
        # if label <5:
            labelDict[label].append(i)
    for value in labelDict.values():
        for idx in np.random.choice(value, size=args.select_sample, replace=False, p=None):
            labeledIndex.append(idx)
    # print(y[labeledIndex])
    return labeledIndex

def initLabeled_ini(y,i,args):
    ## random selected 5000
    y = np.squeeze(y)
    np.random.seed(40+i)
    labeledIndex = []
    labelDict = OrderedDict()
    for label in np.unique(y):
        # if label <5:
            labelDict[label] = []
    for i, label in enumerate(y):
        # if label <5:
            labelDict[label].append(i)
    i = 1
    for value in labelDict.values():
            if args.data == 'Auml_url':
                for idx in np.random.choice(value, size=600-100*i, replace=False, p=None):
                    labeledIndex.append(idx)
                i += 1
            elif args.data == 'puish_url':
                for idx in np.random.choice(value, size=1000, replace=False, p=None):
                    labeledIndex.append(idx)
            else:
                for idx in np.random.choice(value, size=500, replace=False, p=None):
                    labeledIndex.append(idx)
    # print(y[labeledIndex])
    return labeledIndex

def initLabeled_few_shot(y,i,args):
    ## random selected the labeled instances' index
    y = np.squeeze(y)
    np.random.seed(40+i)
    labeledIndex = []
    labelDict = OrderedDict()
    for label in np.unique(y):
        # if label <5:
            labelDict[label] = []
    for i, label in enumerate(y):
        # if label <5:
            labelDict[label].append(i)
    for value in labelDict.values():
        for idx in np.random.choice(value, size=args.k_shot, replace=False, p=None):
            labeledIndex.append(idx)
    # print(y[labeledIndex])
    return labeledIndex
