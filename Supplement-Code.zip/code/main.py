import argparse
import numpy as np
import pandas as pd
import tensorflow as tf
import os
import cal_MSE_MAE
import GFS_train


def exp_main(args):
  if (args.method == "GFS"):
      print(args.method)
      print(args)
      GFS_train.GFS(args)
      cal_MSE_MAE.cal_all_aver_result(args)
  tf.reset_default_graph()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--label_data_rate',help='ratio of labeled data',default=0.2,type=float)      # no used yet
    parser.add_argument('--label_no',help='number of labeled data to be used',default=2000,type=int)  # no used in GFS, do not change this
    parser.add_argument('--iterations', help='number of experiments iterations',default=5, type=int)  # k-flod
    parser.add_argument('--domain', type=str, default='uci')
    parser.add_argument('--data', type=str, default='breast_cancer')  # optdigits: classification energy: regression
    parser.add_argument('--method', type=str, default="GFS")
    parser.add_argument('--problem', type=str, default="Classification")  # Regression,Classification     ,Binary(Binary no used yet)
    parser.add_argument('--tspecial', type=str, default="123")  # Binary/123 (Binary no used yet)
    parser.add_argument('--log_path', type=str, default="./train")
    parser.add_argument('--noise_type', type=str, default="mask")  # mask, s&p, gaussian (this could change, but no used in paper)
    parser.add_argument('--noise_amount', type=float, default=0.5)  # noise
    parser.add_argument('--select_sample', type=int, default=1)  # k samples per class
    parser.add_argument('--hidden_dim', type=int, default=64)
    parser.add_argument('--select_features', type=int, default=30)  # TOP-K: 5 10 30
    parser.add_argument('--Batch_attention_Ablation', type=str, default="GFS")  # GFS / GFS_B
    parser.add_argument('--classifier',type=str,default='lgb')  # lgb/mlp
    args = parser.parse_args()
    list_datasets =['optdigits']  # 'optdigits'  'energy'
    list_methods = ['GFS']
    list_nums = [0.0]  # 0.0,0.1,0.3,0.5
    list_samples = [50]  # 1 5 10 20 30 50 100 200 300
    datasets_num = len(list_datasets)
    method_nums = len(list_methods)
    parser.add_argument('--datasets_num', type=int, default=datasets_num)
    parser.add_argument('--method_nums', type=int, default=method_nums)

    for args.select_sample in list_samples:
        for args.data in list_datasets:
            for args.noise_amount in list_nums:
                for args.method in list_methods:

                    args.path_result = './train/{}_lgb0.7_{}/{}/result_data_{}/{}/{}/'.format(args.data, args.select_sample, args.method, args.hidden_dim, args.noise_type,
                                                                                 args.noise_amount)

                    if not os.path.exists(args.path_result):
                        os.makedirs(args.path_result)
                    args.path_train = './train/{}_lgb0.7_{}/{}/train_data_{}/{}/{}/'.format(args.data, args.select_sample, args.method, args.hidden_dim, args.noise_type,
                                                                               args.noise_amount)
                    if not os.path.exists(args.path_train):
                        os.makedirs(args.path_train)

                    results = exp_main(args)

