# Necessary packages
import keras
import numpy as np
import tensorflow as tf
from tensorflow.contrib import layers as contrib_layers
import pandas as pd


def vime_semi(x_train, y_train, parameters, it, args):
    np.random.seed(40 + it)
    # Network parameters
    hidden_dim = parameters['hidden_dim']
    act_fn = tf.nn.relu
    batch_size = parameters['batch_size']
    iterations = parameters['iterations']
    data_dim = len(x_train[0, :])
    label_dim = len(y_train[0, :])
    # Input placeholder
    # Labeled data
    x_input = tf.placeholder(tf.float32, [None, data_dim])
    y_input = tf.placeholder(tf.float32, [None, label_dim])

    def weight(x_input):
        with tf.variable_scope('weight', reuse=tf.AUTO_REUSE):
            z1 = contrib_layers.fully_connected(x_input, hidden_dim, activation_fn=tf.nn.tanh)
            z2 = contrib_layers.fully_connected(z1, data_dim, activation_fn=None)
            z_bar = tf.reduce_mean(z2, axis=0)
            A = tf.nn.softmax(z_bar)
        return A

    def no_weight(x_input):
        A = tf.reduce_mean(x_input, axis=0)
        return A

    def predictor(x_input):
        with tf.variable_scope('predictor', reuse=tf.AUTO_REUSE):
            inter_layer = contrib_layers.fully_connected(x_input,
                                                         hidden_dim,
                                                         activation_fn=act_fn)
            # inter_layer = contrib_layers.fully_connected(inter_layer,
            #                                              hidden_dim,
            #                                              activation_fn=act_fn)

            y_hat_logit = contrib_layers.fully_connected(inter_layer,
                                                         label_dim,
                                                         activation_fn=None)
            y_hat = tf.nn.softmax(y_hat_logit)
            if args.tspecial == 'Binary':
                y_hat = tf.nn.sigmoid(y_hat_logit)
        return y_hat_logit, y_hat

    A_s = weight(x_input)
    A_r = no_weight(x_input)
    if args.Batch_attention_Ablation == "GFS":
        y_hat_logit, y_hat = predictor(tf.multiply(x_input, A_s))
    if args.Batch_attention_Ablation == "GFS_B":
        y_hat_logit, y_hat = predictor(tf.multiply(x_input, A_r))
    # Defin losses

    # Supervised loss
    if args.problem == "Classification" and args.tspecial != "Binary":
        y_loss = tf.losses.softmax_cross_entropy(y_input, y_hat_logit)  # y_hat_logit
    if args.problem == "Regression":
        y_loss = tf.losses.mean_squared_error(y_input, y_hat_logit)
        # y_loss = tf.losses.huber_loss(y_input, y_hat_logit)   #  huber loss
    if args.tspecial == "Binary":
        y_loss = tf.losses.softmax_cross_entropy(y_input, y_hat_logit) + tf.losses.get_regularization_loss()
    p_vars1 = [v for v in tf.trainable_variables() if v.name.startswith('weight')]
    p_vars2 = [v for v in tf.trainable_variables() if v.name.startswith('predictor')]

    solver = tf.train.AdamOptimizer(learning_rate=0.002).minimize(y_loss, var_list=[p_vars1, p_vars2])

    # Start session
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

    # Training iteration loop
    for it in range(iterations):
        # Select a batch of labeled data
        if args.Batch_attention_Ablation == "GFS_B":
            batch_idx = np.random.permutation(len(x_train[:, 0]))[:1]
            x_batch = x_train[batch_idx, :]
            y_batch = y_train[batch_idx, :]
        else:
            batch_idx = np.random.permutation(len(x_train[:, 0]))[:batch_size]
            x_batch = x_train[batch_idx, :]
            y_batch = y_train[batch_idx, :]

        # Train the model
        if args.Batch_attention_Ablation == "GFS":
            A, _, = sess.run([A_s, solver], feed_dict={x_input: x_batch, y_input: y_batch})
        if args.Batch_attention_Ablation == "GFS_B":
            A, _, = sess.run([A_r, solver], feed_dict={x_input: x_batch, y_input: y_batch})
        # # Current validation loss
        yv_loss_curr = sess.run(y_loss, feed_dict={x_input: x_batch, y_input: y_batch})

        if it % 100 == 0:
            print('Iteration: ' + str(it) + '/' + str(iterations) + ', Current loss: ' + str(np.round(yv_loss_curr, 8)))
    return A
