import argparse
import numpy as np
import pandas as pd
import sklearn.metrics
import load_data_com
import lightgbm as lgbm
import util
from sklearn.metrics import accuracy_score,precision_score,f1_score
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.metrics import f1_score, mean_squared_error, mean_absolute_error, recall_score, precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import os
import cal_MSE_MAE


def load_data(args, label_no, i, normalize=True):
    np.random.seed(i)
    x = pd.read_csv("./datasets/{}/data.csv".format(args.data))
    y = pd.read_csv("./datasets/{}/label.csv".format(args.data))
    df_X, df_y = np.array(x), np.array(y)
    df_y = np.delete(df_y,0,1)
    df_X = df_X[:,1:]
    df_X, df_y = pd.DataFrame(df_X), pd.DataFrame(df_y)
    if normalize:
        x = df_X.values
        min_max_scaler = preprocessing.MinMaxScaler()
        x_scaled = min_max_scaler.fit_transform(x)
        df_X = pd.DataFrame(x_scaled)
    Y = np.array(df_y)
    raw_data = np.array(df_X)

    x_train_raw, x_test_raw, y_train_raw, y_test_raw = train_test_split(raw_data, Y, test_size=0.3, random_state=0)
    # training classifier
    x_train_raw, y_train_raw = np.array(x_train_raw), np.array(y_train_raw)
    y_test_raw = np.array(y_test_raw)
    x_test_raw = np.array(x_test_raw)
    x_test_raw.flatten()
    # x_test_0, x_test_1, x_test_2, x_test_3, x_test_4, x_test_5, x_test_6, x_test_7, x_test_8, x_test_9 = [],[],[],[],[],[],[],[],[],[]
    # y_test_0, y_test_1, y_test_2, y_test_3, y_test_4, y_test_5, y_test_6, y_test_7, y_test_8, y_test_9 = [],[],[],[],[],[],[],[],[],[]
    x_test_0, x_test_1, x_test_2, x_test_3, x_test_4 = [],[],[],[],[]
    y_test_0, y_test_1, y_test_2, y_test_3, y_test_4 = [],[],[],[],[]
    for i, value in enumerate(y_test_raw):
        if y_test_raw[i] == value:
            xclass = 'x_test_{}'.format(value[0])
            yclass = 'y_test_{}'.format(value[0])
            xc = eval(xclass)
            yc = eval(yclass)
            xc.append(x_test_raw[i])
            yc.append(value)
    # x_test_0,x_test_1,x_test_2,x_test_3 , x_test_4, x_test_5, x_test_6, x_test_7, x_test_8, x_test_9= np.array(x_test_0), np.array(x_test_1), np.array(x_test_2), np.array(x_test_3),np.array(x_test_4), np.array(x_test_5), np.array(x_test_6), np.array(x_test_7),np.array(x_test_8), np.array(x_test_9)
    # y_test_0,y_test_1,y_test_2,y_test_3 , y_test_4, y_test_5, y_test_6, y_test_7, y_test_8, y_test_9= np.array(y_test_0), np.array(y_test_1), np.array(y_test_2), np.array(y_test_3),np.array(y_test_4), np.array(y_test_5), np.array(y_test_6), np.array(y_test_7),np.array(y_test_8), np.array(y_test_9)
    x_test_0, x_test_1, x_test_2, x_test_3, x_test_4 = np.array(x_test_0), np.array(x_test_1), np.array(x_test_2), np.array(x_test_3),np.array(x_test_4)
    y_test_0, y_test_1, y_test_2, y_test_3, y_test_4 = np.array(y_test_0), np.array(y_test_1), np.array(y_test_2), np.array(y_test_3),np.array(y_test_4)
    idx = np.random.permutation(len(y_train_raw))
    raw_data_train = x_train_raw[idx, :]
    raw_Y_train = y_train_raw[idx, :]
    # few shot training classifier
    if args.few_shot_mode:
        select_y = util.initLabeled_few_shot(raw_Y_train, i, args)
        raw_data_train = raw_data_train[select_y,:]
        raw_Y_train = raw_Y_train[select_y,:]
    return x_test_raw, y_test_raw, raw_data_train, raw_Y_train,\
           x_test_0,x_test_1,x_test_2,x_test_3 , x_test_4,y_test_0,y_test_1,y_test_2,y_test_3 , y_test_4


def FST(args):
    for it in range(args.iterations):
        np.random.seed(it)
        x_test, y_test, val_x, val_y ,\
        x_test_0,x_test_1,x_test_2,x_test_3 , x_test_4,\
        y_test_0,y_test_1,y_test_2,y_test_3 , y_test_4, = load_data(args, args.label_no, it)
        pred_Y, real_test_Y, ac_score_list = [], [], []
        ac_score_list0,ac_score_list1,ac_score_list2,ac_score_list3,ac_score_list4= [],[],[],[],[]

        use_test_0,use_test_1,use_test_2,use_test_3,use_test_4= x_test_0, x_test_1, x_test_2, x_test_3, x_test_4

        rf = RandomForestClassifier(n_estimators=10)
        rf.fit(val_x, val_y)
        y_pre = rf.predict(x_test)
        pred_Y.append(y_pre)
        real_test_Y.append(y_test)
        y_pre0,y_pre1,y_pre2,y_pre3,y_pre4= rf.predict(use_test_0), rf.predict(use_test_1), rf.predict(use_test_2), rf.predict(use_test_3), rf.predict(use_test_4)
        accuracy0,accuracy1,accuracy2,accuracy3,accuracy4 = f1_score(y_test_0, y_pre0, average='micro'),f1_score(y_test_1, y_pre1, average='micro'),f1_score(y_test_2, y_pre2, average='micro'),f1_score(y_test_3, y_pre3, average='micro'),f1_score(y_test_4, y_pre4, average='micro')
        ac_score_list0.append(accuracy0)
        ac_score_list1.append(accuracy1)
        ac_score_list2.append(accuracy2)
        ac_score_list3.append(accuracy3)
        ac_score_list4.append(accuracy4)
        dy0,dy1,dy2,dy3,dy4 = pd.DataFrame(ac_score_list0),pd.DataFrame(ac_score_list1),pd.DataFrame(ac_score_list2),pd.DataFrame(ac_score_list3),pd.DataFrame(ac_score_list4)
        dy0.to_csv(args.path_result + "{}_[{}]_test_ACC_cls0.csv".format(args.method, it), index=0)
        dy1.to_csv(args.path_result + "{}_[{}]_test_ACC_cls1.csv".format(args.method, it), index=0)
        dy2.to_csv(args.path_result + "{}_[{}]_test_ACC_cls2.csv".format(args.method, it), index=0)
        dy3.to_csv(args.path_result + "{}_[{}]_test_ACC_cls3.csv".format(args.method, it), index=0)
        dy4.to_csv(args.path_result + "{}_[{}]_test_ACC_cls4.csv".format(args.method, it), index=0)


parser = argparse.ArgumentParser()
parser.add_argument('--label_data_rate', help='ratio of labeled data', default=0.2, type=float)  # no used yet
parser.add_argument('--label_no', help='number of labeled data to be used', default=2000, type=int)  # no used in GFS, do not change this
parser.add_argument('--iterations', help='number of experiments iterations', default=5, type=int)  # k-flod
parser.add_argument('--domain', type=str, default='uci')
parser.add_argument('--data', type=str, default='Auml_rebuild')  # optdigits: classification energy: regression
parser.add_argument('--method', type=str, default="GFS")
parser.add_argument('--problem', type=str, default="Classification")  # Regression,Classification     ,Binary(Binary no used yet)
parser.add_argument('--tspecial', type=str, default="123")  # Binary/123 (Binary no used yet)
parser.add_argument('--log_path', type=str, default="./train")
parser.add_argument('--noise_type', type=str, default="mask")  # mask, s&p, gaussian (this could change, but no used in paper)
parser.add_argument('--noise_amount', type=float, default=0.0)  # noise
parser.add_argument('--select_sample', type=int, default=1)  # k samples per class
parser.add_argument('--hidden_dim', type=int, default=64)
parser.add_argument('--select_features', type=int, default=30)  # TOP-K: 5 10 30
parser.add_argument('--Batch_attention_Ablation', type=str, default="GFS")  # GFS / GFS_B
parser.add_argument('--classifier', type=str, default='lgb')  # lgb/mlp
parser.add_argument('--few_shot_mode', type=bool, default=True)  # True : few-shot-learning / False : G-FS
parser.add_argument('--k_shot', type=int, default=1)  # 1 5 10      # few shot learning

args = parser.parse_args()

args.path_result = './train/{}_lgb0.7_{}/{}/result_data_{}/{}/{}/'.format(args.data, args.select_sample, args.method,args.hidden_dim, args.noise_type,args.noise_amount)
if not os.path.exists(args.path_result): os.makedirs(args.path_result)
args.path_train = './train/{}_lgb0.7_{}/{}/train_data_{}/{}/{}/'.format(args.data, args.select_sample, args.method,args.hidden_dim, args.noise_type, args.noise_amount)
if not os.path.exists(args.path_train): os.makedirs(args.path_train)

FST(args)
cal_MSE_MAE.cal_all_avg_all_class(args)

