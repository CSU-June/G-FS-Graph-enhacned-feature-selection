import argparse
import numpy as np
import pandas as pd
import sklearn.metrics
import load_data_com
import lightgbm as lgbm
from sklearn.metrics import accuracy_score,precision_score,f1_score
from semi import vime_semi
from sklearn.neural_network import MLPClassifier, MLPRegressor
import tensorflow as tf
from sklearn.metrics import f1_score, mean_squared_error, mean_absolute_error, recall_score, precision_score
import os
import cal_MSE_MAE



def GFS(args):
    for it in range(args.iterations):
        np.random.seed(40+it)
        # Load data
        x_unlab, x_test, y_test, x_train_weight, y_train_weight, val_x, val_y = load_data_com.load_data(args,args.label_no,it)

        # Train VIME-Semi
        vime_semi_parameters = dict()
        vime_semi_parameters['hidden_dim'] = args.hidden_dim
        vime_semi_parameters['batch_size'] = 128
        vime_semi_parameters['iterations'] = 20000

        weight = vime_semi(x_train_weight, y_train_weight, vime_semi_parameters, it, args)
        weight_rank = list(np.argsort(weight))[::-1]   # rank

        weight_save = pd.DataFrame(weight)
        weight_save.to_csv(args.path_result + "{}_[{}]_weight.csv".format(args.method, it), index=0)

        ac_score_list = []
        MSE_LIST = []
        MAE_LIST = []
        pred_Y = []
        real_test_Y = []

        for K in range(1, args.select_features+1, 1):
            use_train_x = val_x[:, weight_rank[:K]]
            # raw test
            use_test_x = x_test[:, weight_rank[:K]]
            if args.problem == "Classification":
                if args.classifier =='lgb':
                    lgb = lgbm.LGBMClassifier(num_leaves=100, learning_rate=0.05, n_estimators=100)
                if args.classifier == 'mlp':
                    lgb = MLPClassifier(solver='adam', alpha=1e-5, hidden_layer_sizes=(64, 64),learning_rate_init=0.01,max_iter=10000)
            if args.problem == "Regression":
                if args.classifier =='lgb':
                    lgb = lgbm.LGBMRegressor(num_leaves=100, learning_rate=0.05, n_estimators=100)
                if args.classifier == 'mlp':
                    lgb = MLPRegressor(solver='adam', alpha=1e-5, hidden_layer_sizes=(64, 64),learning_rate_init=0.01,max_iter=10000)
            lgb.fit(use_train_x, val_y)
            y_pre = lgb.predict(use_test_x)
            pred_Y.append(y_pre)
            real_test_Y.append(y_test)
            if args.problem == "Regression":
                MAE = mean_absolute_error(y_test, y_pre)
                MSE = mean_squared_error(y_test, y_pre)
                print('Using Top {} features| MSE:{:.4f} |MAE:{:.4f}'.format(K, MSE, MAE))
                MSE_LIST.append(MSE)
                MAE_LIST.append(MAE)
            if args.problem == "Classification":
                accuracy = f1_score(y_test, y_pre, average='micro')
                print('Using Top {} features| accuracy:{:.4f}'.format(K, accuracy))
                ac_score_list.append(accuracy)
        if args.problem == "Regression":
            real_test_Y.append(y_test)
            pre = pd.DataFrame(pred_Y)
            real = pd.DataFrame(y_test)
            pre.to_csv(args.path_train + "{}_pred_test_Y_{}.csv".format(args.method, args.data), index=0)
            real.to_csv(args.path_train + "{}_real_test_Y_{}.csv".format(args.method, args.data), index=0)
            dt3 = pd.DataFrame(MSE_LIST)
            dt3.to_csv(args.path_result + "{}_[{}]_test_MSE.csv".format(args.method, it), index=0)
            dtMAE = pd.DataFrame(MAE_LIST)
            dtMAE.to_csv(args.path_result + "{}_[{}]_test_MAE.csv".format(args.method, it), index=0)

        if args.problem == "Classification":
            dt3 = pd.DataFrame(ac_score_list)

            dt3.to_csv(args.path_result + "{}_[{}]_test_ACC.csv".format(args.method, it), index=0)

        tf.reset_default_graph()
    return weight, ac_score_list